import asyncio
import logging
import os

from aiogram import Bot, Dispatcher
from aiogram.filters import CommandStart, Command
from aiogram.types import Message
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN")

dp = Dispatcher()


@dp.message(CommandStart())
async def start(message: Message) -> None:
    await message.answer(
        "Добро пожаловать в NEXORA DIGITAL!\n\n"
        "Это демонстрационный бот-каталог.\n"
        "/catalog — посмотреть тестовые товары\n"
        "/help — помощь"
    )


@dp.message(Command("catalog"))
async def catalog(message: Message) -> None:
    await message.answer(
        "ТЕСТОВЫЙ КАТАЛОГ\n\n"
        "01 · Daily Planner — 149 ₽ (макет)\n"
        "02 · Creator Calendar — 99 ₽ (макет)\n"
        "03 · Bot Starter — 299 ₽ (макет)\n\n"
        "Покупка пока отключена: это шаблон для разработки."
    )


@dp.message(Command("help"))
async def help_command(message: Message) -> None:
    await message.answer(
        "Нужна помощь? Напишите администратору магазина.\n"
        "Добавьте сюда свой контакт поддержки перед запуском."
    )


@dp.message()
async def fallback(message: Message) -> None:
    await message.answer("Я пока понимаю команды /catalog и /help. Попробуйте одну из них.")


async def main() -> None:
    if not TOKEN or TOKEN == "PASTE_YOUR_BOT_TOKEN_HERE":
        raise RuntimeError(
            "Не найден BOT_TOKEN. Скопируйте .env.example в .env и вставьте токен от BotFather."
        )
    logging.basicConfig(level=logging.INFO)
    bot = Bot(token=TOKEN)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
