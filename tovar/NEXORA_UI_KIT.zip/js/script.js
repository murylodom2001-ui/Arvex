const root = document.documentElement;
const themeToggle = document.getElementById("themeToggle");
const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
const form = document.getElementById("demoForm");
const formMessage = document.getElementById("formMessage");
const dialog = document.getElementById("detailDialog");

themeToggle.addEventListener("click", () => {
  const next = root.dataset.theme === "light" ? "dark" : "light";
  root.dataset.theme = next;
  themeToggle.textContent = next === "light" ? "Включить тёмную тему" : "Включить светлую тему";
});

menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});

mainNav.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  });
});

document.querySelectorAll(".detailBtn").forEach((button) => {
  button.addEventListener("click", () => {
    document.getElementById("dialogTitle").textContent = button.dataset.title;
    document.getElementById("dialogText").textContent = button.dataset.text;
    dialog.showModal();
  });
});

function closeDialog() {
  dialog.close();
}
document.getElementById("closeDialog").addEventListener("click", closeDialog);
document.getElementById("dialogOk").addEventListener("click", closeDialog);

form.addEventListener("submit", (event) => {
  event.preventDefault();
  formMessage.textContent = "Проверка пройдена. Это демо: сообщение не отправлено.";
});
