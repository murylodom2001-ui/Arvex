from pathlib import Path
import shutil

def main():
    raw = input("Путь к папке, которую нужно отсортировать: ").strip().strip('"')
    folder = Path(raw).expanduser()

    if not folder.is_dir():
        print("Ошибка: такая папка не найдена.")
        return

    groups = {}
    for item in folder.iterdir():
        if item.is_file() and item.name != Path(__file__).name:
            ext = item.suffix.lower().lstrip(".") or "Без расширения"
            groups.setdefault(ext, []).append(item)

    if not groups:
        print("В папке нет файлов для сортировки.")
        return

    print("\nПредварительный просмотр:")
    for ext, items in sorted(groups.items()):
        print(f"  {len(items)} файл(ов) -> {ext}/")

    answer = input("\nСоздать папки и переместить файлы? Напишите ДА: ").strip().upper()
    if answer != "ДА":
        print("Отменено. Файлы не изменены.")
        return

    moved = 0
    for ext, items in groups.items():
        target_dir = folder / ext
        target_dir.mkdir(exist_ok=True)
        for source in items:
            target = target_dir / source.name
            counter = 1
            while target.exists():
                target = target_dir / f"{source.stem}_{counter}{source.suffix}"
                counter += 1
            shutil.move(str(source), str(target))
            moved += 1

    print(f"Готово! Перемещено файлов: {moved}")

if __name__ == "__main__":
    main()
