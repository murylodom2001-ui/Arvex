from pathlib import Path

def main():
    raw = input("Путь к папке с файлами: ").strip().strip('"')
    folder = Path(raw).expanduser()

    if not folder.is_dir():
        print("Ошибка: такая папка не найдена.")
        return

    prefix = input("Префикс новых имён (например, photo): ").strip()
    if not prefix:
        print("Префикс не должен быть пустым.")
        return

    files = sorted(
        (p for p in folder.iterdir() if p.is_file() and p.name != Path(__file__).name),
        key=lambda p: p.name.lower()
    )
    if not files:
        print("В папке нет файлов для переименования.")
        return

    width = max(3, len(str(len(files))))
    planned = [(p, folder / f"{prefix}_{i:0{width}d}{p.suffix}") for i, p in enumerate(files, 1)]

    print("\nПредварительный просмотр:")
    for old, new in planned:
        print(f"  {old.name} -> {new.name}")

    # Не разрешаем перезапись существующих файлов или неоднозначные совпадения.
    destinations = [new for _, new in planned]
    if len(set(destinations)) != len(destinations) or any(
        new.exists() and new not in [old for old, _ in planned] for new in destinations
    ):
        print("\nОшибка: одно из новых имён уже занято. Выберите другой префикс.")
        return

    answer = input("\nПереименовать файлы? Напишите ДА: ").strip().upper()
    if answer != "ДА":
        print("Отменено. Имена не изменены.")
        return

    # Двухэтапное переименование помогает избежать конфликтов имён.
    temporary = []
    try:
        for old, _ in planned:
            temp = old.with_name(f".__nexora_tmp_{len(temporary)}__{old.name}")
            while temp.exists():
                temp = temp.with_name("_" + temp.name)
            old.rename(temp)
            temporary.append((temp, old))
        for (temp, old), (_, new) in zip(temporary, planned):
            temp.rename(new)
        print(f"Готово! Переименовано файлов: {len(planned)}")
    except OSError as exc:
        print(f"Не удалось завершить переименование: {exc}")
        print("Проверьте папку: часть файлов могла остаться с временными именами.")

if __name__ == "__main__":
    main()
