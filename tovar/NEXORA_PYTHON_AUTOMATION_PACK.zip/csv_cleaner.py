import csv
from pathlib import Path

def main():
    raw = input("Путь к CSV-файлу: ").strip().strip('"')
    source = Path(raw).expanduser()

    if not source.is_file():
        print("Ошибка: файл не найден.")
        return
    if source.suffix.lower() != ".csv":
        print("Подсказка: выберите файл с расширением .csv.")

    output_raw = input("Имя выходного файла [cleaned_output.csv]: ").strip()
    output = Path(output_raw).expanduser() if output_raw else source.with_name("cleaned_output.csv")
    if not output.is_absolute():
        output = source.parent / output
    if output.resolve() == source.resolve():
        print("Ошибка: выходной файл не должен совпадать с исходным.")
        return
    if output.exists():
        answer = input(f"{output} уже существует. Перезаписать? Напишите ДА: ").strip().upper()
        if answer != "ДА":
            print("Отменено. Исходный файл не изменён.")
            return

    # utf-8-sig помогает читать CSV, сохранённые некоторыми версиями Excel.
    try:
        with source.open("r", encoding="utf-8-sig", newline="") as inp:
            sample = inp.read(4096)
            inp.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=",;\\t")
            except csv.Error:
                dialect = csv.excel
            rows = list(csv.reader(inp, dialect))
        cleaned = [
            [cell.strip() for cell in row]
            for row in rows
            if any(cell.strip() for cell in row)
        ]
        with output.open("w", encoding="utf-8-sig", newline="") as out:
            writer = csv.writer(out, dialect)
            writer.writerows(cleaned)
        print(f"Готово! Строк до очистки: {len(rows)}; после: {len(cleaned)}.")
        print(f"Результат сохранён отдельно: {output}")
    except (OSError, UnicodeError, csv.Error) as exc:
        print(f"Не удалось обработать CSV: {exc}")

if __name__ == "__main__":
    main()
